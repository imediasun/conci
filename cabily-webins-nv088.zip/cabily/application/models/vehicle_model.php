<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 /**
* 
* This model contains all db functions related to vehicle management
* @author Casperon
*
**/

class Vehicle_model extends My_Model{

	
}

?>