<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 * This model contains all db functions related to banner management
 * @author Teamtweaks
 *
 */
class Banner_model extends My_Model
{
	
		
	
}

?>