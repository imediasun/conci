<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 *
 * This model contains all db functions related to user management
 * @author Casperon
 *
 */

class Notification_model extends User_model {

    public function __construct() {
        parent::__construct();
    }

}
