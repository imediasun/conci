<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
* This model contains all db functions related to export management
* @author Casperon
*
**/

class Export_model extends My_Model{
	public function __construct() {
		parent::__construct();
	}
	
}