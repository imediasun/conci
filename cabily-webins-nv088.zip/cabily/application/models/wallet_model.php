<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 *
 * This model contains all db functions related to wallet management
 * @author Casperon
 *
 */
class Wallet_model extends My_Model{
	public function __construct(){
        parent::__construct();

    }
	
	
	
}