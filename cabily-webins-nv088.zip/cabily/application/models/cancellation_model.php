<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 /**
* 
* This model contains all db functions related to Cancellation types management
* @author Casperon
*
**/

class Cancellation_model extends My_Model{

	
}

?>